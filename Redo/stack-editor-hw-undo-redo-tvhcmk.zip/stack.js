// Build your stack class here.
class Stack {}

export default Stack;
